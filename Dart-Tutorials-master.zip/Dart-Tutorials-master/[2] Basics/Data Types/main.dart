int Epic()
{
  return 1;
}

void main()
{
  final v1 = Epic();
  const v2 = 7;
  
  print(v1);
  print(v2);
}