void main()
{
  int i = 10;
  
  // Is Type
  print(i is String);
  
  // Is Not Type
  print(i is! String);
}







