import 'dart:io';

void main()
{
  String str = stdin.readLineSync();

  print(str);
  print("End of application");
}







