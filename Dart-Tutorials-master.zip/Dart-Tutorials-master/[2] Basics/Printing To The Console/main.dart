void main()
{
  print("Hello World");
  print("Another line");
}