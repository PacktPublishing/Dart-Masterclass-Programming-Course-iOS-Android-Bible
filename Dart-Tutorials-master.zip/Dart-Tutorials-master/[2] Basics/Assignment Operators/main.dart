void main()
{
  // Assignment =
  int i = 20;
  
  // NULL only assignment ??=
  int j = 7;
  j ??= 10;
  //print(j);
  
  // Add assignment +=
  int num1 = 10;
  //print(num1);
  num1 += 5; // num1 = num1 + 5;
  //print(num1);
  
  // Subtract assignment -=
  int num2 = 10;
  //print(num2);
  num2 -= 5; // num2 = num2 - 5;
  //print(num2);
  
  // Multiply assignment *=
  int num3 = 10;
  print(num3);
  num3 *= 5; // num3 = num3 * 5;
  print(num3);
  
  // Divide assignment /=
  double num4 = 10;
  print(num4);
  num4 /= 5; // num4 = num4 / 5;
  print(num4);
}







