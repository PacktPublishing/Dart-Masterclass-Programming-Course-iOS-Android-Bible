void main()
{
  bool var1 = true;
  var1 = 670 > 89;
  
  print(var1);
}