void main()
{
  int num1 = 10;
  int num2 = 5;
  
  // Greater than >
  print(num1 > num2);
  
  // Less than <
  print(num1 < num2);
  
  // Greater than or equal to >=
  print(num1 >= num2);
  
  // Less than or equal to <=
  print(num1 <= num2);
  
  // Equal to ==
  print(num1 == num2);
  
  // Not equal !=
  print(num1 != num2);
}







