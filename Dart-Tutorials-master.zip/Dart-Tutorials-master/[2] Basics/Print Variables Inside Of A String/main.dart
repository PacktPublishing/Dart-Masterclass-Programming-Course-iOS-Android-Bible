void main()
{
  var age = 90;
  var food = "Hello World $age";
  
  print("I am $age and I love eating $food");
  print(food);
}