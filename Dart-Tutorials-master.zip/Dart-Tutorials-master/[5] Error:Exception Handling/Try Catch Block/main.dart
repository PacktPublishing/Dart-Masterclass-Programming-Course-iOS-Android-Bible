void main()
{  
  int num1 = 10;
  int num2 = 6;
  
  try
  {
    print(num1 ~/ num2);
  }
  catch (error)
  {
    print(error);
  }
  
  print("End of Application");
}







