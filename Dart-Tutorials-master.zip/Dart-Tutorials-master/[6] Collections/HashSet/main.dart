import 'dart:collection';

void main()
{  
  Set epicSet = new HashSet();
  
  epicSet.add(10);
  epicSet.add(20);
  epicSet.add(30);
  epicSet.add(40);
  epicSet.add(50);
  epicSet.add(10);
  
  print(epicSet);
}







