import 'dart:collection';

void main()
{  
  var hashy = new HashMap();
  
  hashy['key1'] = 10;
  hashy['key2'] = "Hello World";
  
  print(hashy);
  print(hashy['key2']);
}







