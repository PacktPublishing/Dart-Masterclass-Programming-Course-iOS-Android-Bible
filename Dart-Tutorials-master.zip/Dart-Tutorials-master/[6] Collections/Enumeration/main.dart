enum SuperHeroes
{
  Yoda,
  Batman,
  Superman,
  Lantern
}

void main()
{  
  print(SuperHeroes.Yoda.index);
  print(SuperHeroes.Batman.index);
  print(SuperHeroes.Superman.index);
  print(SuperHeroes.Lantern.index);
}







