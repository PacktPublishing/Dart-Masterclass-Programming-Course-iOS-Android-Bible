void main()
{
  int num1 = 900;
  
  var result = num1 < 100 ? "It is less than 100" : "It is more than 100";
  
  print(result);
  
  int num2 = 7;
  
  var result2 = num2 ?? "It is null";
  
  print(result2);
}







