void main()
{
  /*for (int i = 0; i <= 100; i++)
  {
    print(i * i);
  }*/
  
  int i = 0;
  
  while (i <= 100)
  {
    print(i * i);
    
    i++;
  }
}







