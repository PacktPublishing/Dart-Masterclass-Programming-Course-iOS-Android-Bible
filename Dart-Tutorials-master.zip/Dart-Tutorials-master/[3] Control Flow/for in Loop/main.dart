void main()
{
  var i = [1, 2, 3, 4, 67, 89, 0];
  
  for (var val in i)
  {
    print(val);
  }
}







