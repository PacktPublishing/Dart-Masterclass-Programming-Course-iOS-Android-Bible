void main()
{
  /*int i = 10;
  
  while (i <= 5)
  {
    print(i * i);
    
    i++;
  }*/
  
  int x = 10;
  
  do
  {
    print(x * x);
    
    x++;
  }
  while (x <= 5);
}







