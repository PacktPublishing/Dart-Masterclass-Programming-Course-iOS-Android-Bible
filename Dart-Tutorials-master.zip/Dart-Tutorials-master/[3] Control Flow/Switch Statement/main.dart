void main()
{
  int x = 9;
  
  switch (x)
  {
    case 0:
      print("0");
      break;
      
    case 1:
      print("1");
      break;
      
    case 2:
      print("2");
      break;
      
    case 3:
      print("3");
      break;
      
    case 4:
      print("4");
      break;
     
    case 5:
      print("5");
      break;
      
    default:
      print("Default");
      break;
  }
  
  
  /*if (x == 0)
  {
    print("Is 0");
  }
  else if (x == 1)
  {
    print("Is 1");
  }
  else if (x == 2)
  {
    print("Is 2");
  }
  else if (x == 3)
  {
    print("Is 3");
  }
  else if (x == 4)
  {
    print("Is 4");
  }
  else if (x == 5)
  {
    print("Is 5");
  }
  else
  {
    print("Default");
  }*/
}







