void main()
{  
  Add(5, num3: 7, num2: 8);
}

void Add(int num1, {int num2, int num3})
{
  //print(num1 + num2);
  print(num1);
  print(num2);
  print(num3);
}






