void main()
{  
  Add(5, 7);
  Add(-9, 2);
  Add(99);
}

void Add(int num1, [int num2])
{
  //print(num1 + num2);
  print(num1);
  print(num2);
}






