void main()
{  
  EpicName();
}

void EpicName()
{
  print("Hello World");
}






