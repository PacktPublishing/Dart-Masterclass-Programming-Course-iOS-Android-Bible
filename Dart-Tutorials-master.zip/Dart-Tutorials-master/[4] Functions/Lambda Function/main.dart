void main()
{  
  Epic();
  
  String res = EpicReturn();
  
  print(res);
}

Epic() => print("We are epic");

String EpicReturn() => "Hi";







