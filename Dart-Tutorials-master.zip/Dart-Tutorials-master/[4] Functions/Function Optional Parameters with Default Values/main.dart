void main()
{  
  Add(5, num2: 8, num3: -7);
}

void Add(int num1, {int num2, int num3: 89})
{
  //print(num1 + num2);
  print(num1);
  print(num2);
  print(num3);
}






