library custom_lib;
import 'dart:math';

void main()
{  
  int i = 9;
  print(sqrt(i));
}







