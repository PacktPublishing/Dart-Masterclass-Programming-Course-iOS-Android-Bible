void main()
{
  int x = 10;
  int y = 20;

  y = 90;

  print(x * y);
}